from setuptools import setup

setup(
    name='paquete_1',
    version='1.0',
    description='primer paquete',
    author='Belen',
    author_email='bel@mail.com',
    packages=['paquete_1']
)